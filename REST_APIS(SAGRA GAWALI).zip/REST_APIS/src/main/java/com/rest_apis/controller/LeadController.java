package com.rest_apis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rest_apis.palyload.LeadModel;
import com.rest_apis.palyload.Response;
import com.rest_apis.service.LeadService;

@RestController
@RequestMapping("/apis")
public class LeadController {

	@Autowired
	private LeadService leadService;

	@PostMapping("/create")
	public Response addUser(@RequestBody LeadModel leadModel) {

		Response response = this.leadService.createLead(leadModel);

		return response;
	}
	
	@GetMapping("/getLeadByMobileNumber/{mobileNumber}")
	public Response getUserById(@PathVariable("mobileNumber") String mobileNumber) {

		Response response = this.leadService.getLeadByMobileNumber(mobileNumber);

		return response;

	}

}
