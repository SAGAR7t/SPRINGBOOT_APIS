package com.rest_apis.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.util.Date;

@Entity
@Table(name = "`Lead`")
@Getter
@Setter
@ToString
public class Lead {

	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name = "LEAD_ID" , nullable = false)
	 private int leadId;

    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "MIDDLE_NAME")
    private String middleName;

    @Column(name = "LAST_NAME")
    private String lastName;
    
    @Column(name = "DATE_OF_BIRTH")
    private Date dateOfBirth;

    @Column(name = "MOBILE_NUMBER",unique = true)
    private String mobileNumber;

    @Column(name = "GENDER")
    private String gender;

    @Column(name = "EMAIL",unique = true, nullable = false)
    private String email;

}
