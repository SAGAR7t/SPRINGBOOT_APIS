package com.rest_apis.palyload;


import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class LeadModel {

	private int leadId;
	
	private String firstName;

	private String middleName;

	private String lastName;

	private String mobileNumber;

	private String gender;

	private String email;

	private String dateOfBirth;

}
