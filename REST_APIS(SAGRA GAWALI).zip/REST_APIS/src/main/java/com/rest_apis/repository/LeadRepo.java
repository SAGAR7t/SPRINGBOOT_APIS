package com.rest_apis.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rest_apis.entities.Lead;

public interface LeadRepo extends JpaRepository<Lead, Integer> {

	@Query("From Lead where mobileNumber=:mobileNumber")
	public Lead getLeadByMobileNumber(String mobileNumber);

}
